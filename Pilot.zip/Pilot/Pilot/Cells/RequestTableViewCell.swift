//
//  RequestTableViewCell.swift
//  Pilot
//
//  Created by Artem Myachkov on 20/07/2019.
//  Copyright © 2019 Artem Myachkov. All rights reserved.
//

import UIKit

class RequestTableViewCell: UITableViewCell {

    @IBOutlet weak var imageM: UIImageView!
    @IBOutlet weak var descrLbl: UILabel!
    @IBOutlet weak var mainLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
