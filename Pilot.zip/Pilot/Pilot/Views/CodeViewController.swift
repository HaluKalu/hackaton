//
//  ViewController.swift
//  Pilot
//
//  Created by Artem Myachkov on 20/07/2019.
//  Copyright © 2019 Artem Myachkov. All rights reserved.
//

import UIKit
import Alamofire

class CodeViewController: UIViewController {
    
    @IBOutlet weak var codeField: UITextField!
    @IBAction func lastButton(_ sender: UIButton) {
        
        let x = UserDefaults.standard.object(forKey: "phone") as! String
        
        Alamofire.request("reg/verify?code=" + codeField.text! + "&number=" + x).responseJSON { response in
            
            
            let json = response.result.value as? NSDictionary
            print(json)
        }
        
        if let tabViewController = storyboard?.instantiateViewController(withIdentifier: "TabBarController") as? TabViewController {
            present(tabViewController, animated: true, completion: nil)
        }
    }
    @IBOutlet weak var lastGoView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
//        navigationController?.setNavigationBarHidden(false, animated: false)
        lastGoView.layer.cornerRadius = 13
        lastGoView.layer.masksToBounds = true

        
    }
    
    
}

