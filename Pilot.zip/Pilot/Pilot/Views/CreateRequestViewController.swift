//
//  ViewController.swift
//  Pilot
//
//  Created by Artem Myachkov on 20/07/2019.
//  Copyright © 2019 Artem Myachkov. All rights reserved.
//

import UIKit
import Alamofire

class CreateRequestViewController: UIViewController {
    @IBOutlet weak var descr: UITextField!
    
    @IBOutlet weak var main: UITextField!
    @IBAction func addButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
        
        
        UserDefaults.standard.set(main.text, forKey: "main")
        UserDefaults.standard.set(descr.text, forKey: "descr")
        
        
        Alamofire.request("http://194.58.120.93/create_problem?number=''&lat='48.7142916'&lon='44.5276648'&name='\(main.text)'&discr='\(descr.text)'&type=''").responseJSON { response in
            
            
            let json = response.result.value as? AnyObject
            print(json)
            
        }
        
    }
    @IBOutlet weak var acceptView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tabBarController?.tabBar.isHidden = true
        
        self.acceptView.layer.masksToBounds = true
        self.acceptView.layer.cornerRadius = 13
    }
    
    override func viewWillAppear(_ animated: Bool) {
    }
    
}


