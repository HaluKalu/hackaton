//
//  ViewController.swift
//  Pilot
//
//  Created by Artem Myachkov on 20/07/2019.
//  Copyright © 2019 Artem Myachkov. All rights reserved.
//

import UIKit
import Alamofire

class RequestViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var data = [CellData]()
    
    @IBOutlet weak var tbl: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Alamofire.request("http://194.58.120.93/take_point/5d3430bb1f78ae10d445f23e").responseJSON { response in
            
            
            let json = response.result.value as? AnyObject
            let newJson = json
            let descr = (newJson as AnyObject)["discr"]
            let name = (newJson as AnyObject)["name"]
            let lon = (newJson as AnyObject)["lon"]
            let lat = (newJson as AnyObject)["lat"]
            
            let newDescr = descr as! String
            let newName = name as! String
            
            
            let xx = CellData(mainL: newName, descrL: newDescr, metka: "62.927930 93.93837", adress: "")
            self.data.append(xx)
            
            DispatchQueue.main.async {
                self.tbl.reloadData()
            }
            
        }
        
        Alamofire.request("http://194.58.120.93/take_all_points").responseJSON { response in
            
            
            let json = response.result.value as? NSArray
            print(json)
    
            
        }
        
        self.tbl.delegate = self
        self.tbl.dataSource = self

        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.tabBar.isHidden = false
        let a = UserDefaults.standard.object(forKey: "main") as? String
        let b = UserDefaults.standard.object(forKey: "descr") as? String
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 130
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! RequestTableViewCell
        cell.selectionStyle = .none
        cell.mainLbl.text = data[indexPath.row].mainL
        cell.descrLbl.text = data[indexPath.row].descrL
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? FullInfoViewController{
            destination.info = data[(tbl.indexPathForSelectedRow?.row)!]
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "cell", sender: self)
    }
    
}

