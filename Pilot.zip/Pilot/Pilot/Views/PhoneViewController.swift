//
//  ViewController.swift
//  Pilot
//
//  Created by Artem Myachkov on 20/07/2019.
//  Copyright © 2019 Artem Myachkov. All rights reserved.
//

import UIKit
import Alamofire


class PhoneViewController: UIViewController {
    
    @IBOutlet weak var phoneField: UITextField!
    @IBAction func ssendButton(_ sender: Any) {
        UserDefaults.standard.set(phoneField.text, forKey: "phone")
        print(phoneField.text)
        Alamofire.request("http://194.58.120.93/reg/phone?phone=" + phoneField.text!).responseJSON { response in


            let json = response.result.value as? NSDictionary
            print(json)
    }
    }
    
    @IBOutlet weak var sendButton: UIButton!
    @IBOutlet weak var goView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
//        navigationController?.setNavigationBarHidden(false, animated: false)
        let backItem = UIBarButtonItem(title: "Назад", style: .bordered, target: nil, action: nil)
        navigationItem.backBarButtonItem = backItem
        goView.layer.cornerRadius = 13
        goView.layer.masksToBounds = true
        
    }
    
}

