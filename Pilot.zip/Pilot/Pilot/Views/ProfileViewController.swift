//
//  ViewController.swift
//  Pilot
//
//  Created by Artem Myachkov on 20/07/2019.
//  Copyright © 2019 Artem Myachkov. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tabBarController?.tabBar.isHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.tabBar.isHidden = false
    }
    
}

