//
//  ViewController.swift
//  Pilot
//
//  Created by Artem Myachkov on 20/07/2019.
//  Copyright © 2019 Artem Myachkov. All rights reserved.
//

import UIKit

class MapViewController: UIViewController {
    
    @IBAction func Button(_ sender: Any) {        
        let url2 = "http://194.58.120.93/map"
        let mapURL2 = URL(string: url2)
        self.map.loadRequest(URLRequest(url: mapURL2!))
    }
    
    @IBOutlet weak var map: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.hidesBackButton = true
        
        let url = "http://194.58.120.93/map"
        let mapURL = URL(string: url)
        map.loadRequest(URLRequest(url: mapURL!))
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.tabBar.isHidden = false
  
        
    }
    
    
    
}

