//
//  ViewController.swift
//  Pilot
//
//  Created by Artem Myachkov on 20/07/2019.
//  Copyright © 2019 Artem Myachkov. All rights reserved.
//

import UIKit
import Alamofire

class FullInfoViewController: UIViewController {
    @IBOutlet weak var viewview: UIView!
    
    @IBOutlet weak var mainLabel: UILabel!
    var info : CellData?
    @IBOutlet weak var metka: UILabel!
    
    @IBOutlet weak var descr: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.tabBarController?.tabBar.isHidden = true
        self.title = info?.mainL
        self.mainLabel.text = info?.mainL
        self.descr.text = info?.descrL
        self.metka.text = (info?.metka)! + " ул. имени Ленина, 29 "
        viewview.layer.masksToBounds = true
        viewview.layer.cornerRadius = 17
        
    }
    
    override func viewWillAppear(_ animated: Bool) {

    }
    
    
}

