//
//  ViewController.swift
//  Pilot
//
//  Created by Artem Myachkov on 20/07/2019.
//  Copyright © 2019 Artem Myachkov. All rights reserved.
//

import UIKit

class FilterViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tbbbl: UITableView!
    
    
    @IBOutlet weak var acceptView: UIView!
    @IBAction func goBack(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    var types = ["Ямы","Погодные условия","Аварии"]
    
    // do checkBox
    
    override func viewDidLoad() {
        super.viewDidLoad()
        acceptView.layer.cornerRadius = 13
        acceptView.layer.masksToBounds = true
        self.tabBarController?.tabBar.isHidden = true
        
        self.tbbbl.delegate = self
        self.tbbbl.dataSource = self
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return types.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "filterCell", for: indexPath)
        let item = types[indexPath.row]
        cell.textLabel?.text = item
        cell.selectionStyle = .none
        return cell
    }
    
}


