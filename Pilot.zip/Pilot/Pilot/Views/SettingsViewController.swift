//
//  ViewController.swift
//  Pilot
//
//  Created by Artem Myachkov on 20/07/2019.
//  Copyright © 2019 Artem Myachkov. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {
    
    @IBAction func popView(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    @IBOutlet weak var acceptView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tabBarController?.tabBar.isHidden = true
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(title: "Выйти", style: .done, target: self, action: #selector(goBack))
        
        self.acceptView.layer.masksToBounds = true
        self.acceptView.layer.cornerRadius = 13
        
    }

    @objc func goBack(){
        let viewController = self.storyboard?.instantiateViewController(withIdentifier: "LaunchVC") as! LaunchViewController
        let navController = UINavigationController(rootViewController: viewController)
        self.present(navController, animated:true, completion: nil)
    }
    
    
}


