    import UIKit
    import Foundation
    
    struct CellData{
        let mainL : String?
        let descrL : String?
        let metka: String?
        let adress: String?

        init(mainL : String, descrL : String, metka : String, adress : String){
        self.mainL = mainL
        self.descrL = descrL
        self.adress = adress
        self.metka = metka
    }
}
